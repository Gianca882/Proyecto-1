#pragma once
//class ordenamiento
//{
    //Pila<T> ordenar(Pila<T>Playlist)
       //Pila <T> PilaN = new Pila<>();

    //while (Playlist.peek() != null) {
       // T dato = Playlist.pop();
       // situar(dato, Playlist, new Pila<T>());
   // }
    //return Playlist;

        //void situar(T dato, Pila<T> Playlist, Pila<T> aux){
       // if(Playlist.peek()==null){
           // Playlist.push(dato);
            //vaciarAux(Playlist, aux)
        //}
       // else{
           // if(dato.CompareTo(Playlist.peek())<=0){
               // Playlist.push(dato);
///vaciarAux(Playlist, aux);

            //}
            //else{
                //aux.push(Playlist.pop());
                //situar(dato, Playlist, aux)
           // }//
       // }
 
  //  }
   // private void vaciarAux(T dato, Pila<T> Playlist, Pila<T> aux){
     //   while(aux.peek()!=null){
        //    Playlist.push(aux.pop);
       // }
   // }


//};

